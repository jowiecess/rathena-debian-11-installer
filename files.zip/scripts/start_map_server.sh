#!/bin/sh
cd /home/rathena/Desktop/rAthena
./map-server
